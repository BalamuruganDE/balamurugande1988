package hackathonbala

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.inceptez.hack.allmethods;

// import org.apache.spark.sql.SQLImplicits


/*s
 8. Add case class namely insureclass with the field names used as per the header record in 
the file and apply to the above data to create schemaed RDD.
 */

//case class Customer(name: String, city: String, age: Int) 
// Case class insureclass creation

case class insureclass (IssuerId:Int,IssuerId2:Int,BusinessDate:String,StateCode:String,SourceName:String,
    NetworkName:String,NetworkURL:String,custnum:String,MarketCoverage:String,DentalOnlyPlan:String)


    case class insureclass1 (IssuerId:String,IssuerId2:String,BusinessDate:String,StateCode:String,SourceName:String,
    NetworkName:String,NetworkURL:String,custnum:String,MarketCoverage:String,DentalOnlyPlan:String)

    
object scalahack1 {
  def main (args:Array[String]){
    println ("My Hackathon Project1 ...")
    
    /*  val conf= new SparkConf().setMaster("local[*]").setAppName("balahackathon")
      val sc= new SparkContext(conf)
      sc.setLogLevel("Error")
      val sqlc=new SQLContext(sc)*/
    
    
    //Creation of Spark Session
    val spark = SparkSession.builder().appName("balahackathon").master("local[*]")
    .enableHiveSupport.
    config("spark.eventLog.dir","file:///tmp/spark-events").
    config("spark.history.fs.logDirectory","file:///tmp/spark-events").
    config("spark.eventLog.enabled","true").
    //config("hive.metastore.uris",args(5)).//"thrift://127.0.0.1:9083").
    config("hive.metastore.uris","thrift://localhost:9083").
    config("spark.sql.warehouse.dir","hdfs://localhost:54310/user/hive/warehouse").
    config("spark.sql.shuffle.partitions",4).
    getOrCreate()
    
    println("Spark Version:"+spark.version)
    
    val sc = spark.sparkContext
    sc.setLogLevel("Error")
    
     // Creating file RDD
    val insuredata = sc.textFile("hdfs://localhost:54310/user/hduser/sparkhack2/insuranceinfo1.csv")  
    println ("insuredata count:"+insuredata.count)
   // println("Complete insuredata RDD:"+insuredata.count)
    //insuredata.top(5).foreach(println)
    val insuredatacount=insuredata.count
    
    // Header Removal
    val insuredataheader = insuredata.first
    //val insuredatanoheader = insuredat.filter (x=> x !=insuredataheader)
    val insuredatanoheader = insuredata.filter (x=> !x.contains(insuredataheader))
    println("insuredata RDD with no header:"+insuredatanoheader.count)
   // insuredatanoheader.top(3).foreach(println)
    
      // 3. Remove the Footer/trailer also which contains “footer count is 404”
    
    /*  // This peice of code didn't work
    val footer = insuredata.filter (x=> x.contains("footer"))
    footer.foreach(println)
    val footerremoved = insuredata.filter (x=> !x.contains(footer))
    val insuredatanoheaderfooter=footerremoved.filter (x=> x.contains("footer")).collect
    println("insuredata no header & footer:")
    insuredatanoheaderfooter.foreach(println) */
    
    // Footer removal using zipWithIndex function
    val indexadddata = insuredatanoheader.zipWithIndex
    
    
    val indexaddcount=indexadddata.count
    val insuredatanoheaderfooter1=indexadddata.filter (x=> x._2 < indexaddcount -1 ).map(x=>x._1)
    //4. Display the count and show few rows and check whether header and footer is removed.
    
    println("insuredata with no header & footer count:"+insuredatanoheaderfooter1.count)
    println("insuredata with no header & footer (sample data):")
    insuredatanoheaderfooter1.top(5).foreach(println)
    val insuredatanoheaderfootercount=insuredatanoheaderfooter1.count
    
    // 5. Remove the blank lines in the rdd.
    val removeofbalnks=insuredatanoheaderfooter1.map(x=>x.trim).filter(l=>l.length != 0)
        
    
    //6. Map and split using ‘,’ delimiter. 
    
    val splitinsurerdd = removeofbalnks.map(_.split(",",-1))
    println("6. Map and split using ‘,’ delimiter. ")
    val firstspltrdd=splitinsurerdd.first.mkString("")
    println(firstspltrdd)
    
    
    /*7. Filter number of fields are equal to 10 columns only - analyze why we are doing this and 
    provide your view here.. */
    
    /*
     	
     	We are doing this validation because so that we can only allow the valid data for processing 
     	
     */
    
    
    val fieldmatchcount=splitinsurerdd.filter(l=>l.length == 10).count
    println ("Count of records matching 10 columns:"+fieldmatchcount)
    
    val validinsurerdd=splitinsurerdd.filter(l=>l.length == 10)
    
    /*
         * 8. Add case class namely insureclass with the field names used as per the header record in 
    the file and apply to the above data to create schemaed RDD.
         * */
    
    // Applying the validinsurerdd to the case class 
    
    //case class insureclass (IssuerId:Int,IssuerId2:Int,BusinessDate:String,StateCode:String,SourceName:String,
    //  NetworkName:String,NetworkURL:String,custnum:String,MarketCoverage:String,DentalOnlyPlan:String)
    
    
    val dtck1 = new allmethods;
    val schemardd = validinsurerdd.map(x=>insureclass(x(0).toInt,x(1).toInt,x(2),x(3),x(4),x(5),x(6),
        x(7),x(8),x(9)))
    
        schemardd.take(2).foreach(println)
        
    /*
    9. Take the count of the RDD created in step 7 and step 1 and print how many rows are
    removed/rejected in the cleanup process of removing fields does not equals 10
    */
    
    val recorddiffcount=insuredatanoheaderfootercount-fieldmatchcount
    println(recorddiffcount)
    
    
    /*
     * 
     * 10. Create another RDD namely rejectdata and store the row that does not equals 10 
     			 columns. With a new column added in the first column called numcols contains number 
           of columns in the given row For eg - the output should be like this: (6,219) where 6 is 
           the number of columns and 219 is the first column IssuerId of the data hence 
           we can analyse the IssuerIds contains deficient fields.
     * 
     */
    
    val rejectdata1=splitinsurerdd.filter(l=>l.length != 10)
    //val rejectdata=rejectdata1.map(x=>(x(0),x(1))).collect.mkString("")
    val rejectdata=rejectdata1.collect//.mkString("").map(x=>x)
      rejectdata.foreach(println)   
     // println("Rejected Data:"+rejectdata)
    //println+rejectdata)
    
    
    //new column addition
    
    val rejcollength= rejectdata1.map(l=>l.length)
    println(rejcollength)
    
    val rejdata=rejcollength.zip(rejectdata1.map(x=>x(0)))
    rejdata.foreach(println)
    
    
    
    /*
     * 11. Load the file2 (insuranceinfo2.csv) from HDFS using textFile API into an RDD insuredata2
     * */
    val insuredata2 = sc.textFile("hdfs://localhost:54310/user/hduser/sparkhack2/insuranceinfo2.csv")
    
    /*
     *  12. Repeat from step 2 to 8 for this file also and create the schemaed rdd from the 
        insuranceinfo2.csv and filter the records that contains blank or null IssuerId,IssuerId2 
        for eg: remove the records with pattern given below.
        ,,,,,,,13,Individual,Yes
     */
    
    val insuredata2header = insuredata2.first
    
    val insuredata2noheader = insuredata2.filter (l => !l.contains(insuredata2header))
    
    val insuredata2noheadercount = insuredata2noheader.count
    
    val  insuredata2inddata=insuredata2noheader.zipWithIndex
    
    val insuredata2noheaderfooter=insuredata2inddata.filter(l=>l._2 < insuredata2noheadercount -1).map(x=>x._1)
    
    
    println ("insuredata2 count without header and footer:"+insuredata2noheaderfooter.count)
    
    val insuredata2formatted1=insuredata2noheaderfooter.map(x=>x.trim).filter(l=>l.length !=0)
    
    val insuredata2formatted = insuredata2formatted1.map(_.split(",",-1))
    
    val insuredata2formatted2 = insuredata2formatted1.map(_.split(",",-1)).collect.mkString("")
      
     // insuredata2formatted2.take(5).foreach(println)
    
    val fieldmatchcount2= insuredata2formatted.filter(l=>l.length == 10).count
    
    println("insuredata2 filed match count:"+fieldmatchcount2)
      
       val fieldmatch2= insuredata2formatted.filter(l=>l.length == 10)
      
        val schemardd1 = fieldmatch2.map(x=>insureclass1(x(0),x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9)))
    
    schemardd1.take(2).foreach(println)
    
    
    
      val invaliddata2=schemardd1.filter(x=> x.IssuerId == "" || x.IssuerId2 == "" )
    
    invaliddata2.take(5).foreach(println)
    
    val validdata2=schemardd1.filter(x=> x.IssuerId != "" || x.IssuerId2 != "" )
    
     println("insuredata2 invalid data count:"+invaliddata2.count)
     
     println("insuredata2 valid data count:"+validdata2.count)
    
    
    
    /*
     * 13. Merge the both header and footer removed RDDs derived in steps 8 and 12 into an RDD 
    	 namely insuredatamerged
     * 
     */
      val insuredatamerged=(schemardd.map(x=>(x.IssuerId,x.IssuerId2,dtck1.dtck(x.BusinessDate),x.StateCode,x.SourceName,x.NetworkName,x.NetworkURL,x.custnum,x.MarketCoverage,x.DentalOnlyPlan))).
     union(validdata2.map(x=>(x.IssuerId.toInt,x.IssuerId2.toInt,dtck1.dtck(x.BusinessDate),x.StateCode,x.SourceName,x.NetworkName,x.NetworkURL,x.custnum,x.MarketCoverage,x.DentalOnlyPlan)))
      
    
      println("insuredatamerged merged RDD count:"+insuredatamerged.count)
     
     
     /*
    * 14. Persist the step 13 RDD to memory by serializing.
    * 
    */
    
      insuredatamerged.persist()
      
     /*
        15. Calculate the count of rdds created in step 8+12 and rdd in step 13, check whether they 
        are matching.
     */
     
      val count1=validdata2.count+schemardd.count
      val count2=insuredatamerged.count
      println ("count1:"+count1+"	--->	count2:"+count2)
    
    if (count1 == count2) {println ("Both the induvidual and merged count matches")} 
    else {println ("Both the induvidual and merged doesn't count matches")}
    
    /*
     * 16. Remove duplicates from this merged RDD created in step 13 and print how many 
    	 duplicate rows are there.
    */
    
           val insuredatamerged1=(schemardd.map(x=>(x.IssuerId,x.IssuerId2,dtck1.dtck(x.BusinessDate),x.StateCode,x.SourceName,x.NetworkName,x.NetworkURL,x.custnum,x.MarketCoverage,x.DentalOnlyPlan))).
     union(validdata2.map(x=>(x.IssuerId.toInt,x.IssuerId2.toInt,dtck1.dtck(x.BusinessDate),x.StateCode,x.SourceName,x.NetworkName,x.NetworkURL,x.custnum,x.MarketCoverage,x.DentalOnlyPlan))).distinct
     
     println("insuredatamerged merged RDD unique count:"+insuredatamerged1.count);
        
     val insuredatamergedinter=(schemardd.map(x=>(x.IssuerId,x.IssuerId2,dtck1.dtck(x.BusinessDate),x.StateCode,x.SourceName,x.NetworkName,x.NetworkURL,x.custnum,x.MarketCoverage,x.DentalOnlyPlan)))
     .intersection(validdata2.map(x=>(x.IssuerId.toInt,x.IssuerId2.toInt,dtck1.dtck(x.BusinessDate),x.StateCode,x.SourceName,x.NetworkName,x.NetworkURL,x.custnum,x.MarketCoverage,x.DentalOnlyPlan)))
     //.collect
     
       insuredatamergedinter.foreach(println)
       
       println("insuredatamerged duplicate records:"+insuredatamergedinter.count);
     
        /*
     * 17. Increase the number of partitions in the above rdd to 8 and name it as 
    insuredatarepart
     */
     
       println("Current partition size:"+insuredatamerged1.partitions.size)
     
     val insuredatarepart = insuredatamerged1.repartition(8)
     
     println("Repartition partition size:"+insuredatarepart.partitions.size)
     
     
     
     
     /*
    * 18. Split the above RDD using the businessdate field into rdd_20191001 and rdd_
      20191002 based on the BusinessDate of 2019-10-01 and 2019-10-02 respectively using 
      Filter function
    */
     
     
    	val rdd_20191001 = insuredatarepart.filter(x=>x._3 == "2019-10-01" || x._3 == "01-10-2019")
    
    val rdd_20191002 = insuredatarepart.filter(x=>x._3 == "2019-10-02" || x._3 == "02-10-2019")
    
    
    /*
     * 19. Store the RDDs created in step 10, 13, 18 into HDFS locations.
    */
     
              val fs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI("hdfs://localhost:54310"), sc.hadoopConfiguration)
    fs.delete(new org.apache.hadoop.fs.Path("hdfs://localhost:54310/user/hduser/sparkhack2/rejectdata"),true)
    rejdata.saveAsTextFile("hdfs://localhost:54310/user/hduser/sparkhack2/rejectdata")
    fs.delete(new org.apache.hadoop.fs.Path("hdfs://localhost:54310/user/hduser/sparkhack2/insuredatamerged"),true)
    insuredatamerged.saveAsTextFile("hdfs://localhost:54310/user/hduser/sparkhack2/insuredatamerged")
    fs.delete(new org.apache.hadoop.fs.Path("hdfs://localhost:54310/user/hduser/sparkhack2/rdd_20191001"),true)
    rdd_20191001.saveAsTextFile("hdfs://localhost:54310/user/hduser/sparkhack2/rdd_20191001")
    fs.delete(new org.apache.hadoop.fs.Path("hdfs://localhost:54310/user/hduser/sparkhack2/rdd_20191002"),true)
    rdd_20191002.saveAsTextFile("hdfs://localhost:54310/user/hduser/sparkhack2/rdd_20191002")
    
    /*
     * 20. Convert the RDD created in step 17 above into Dataframe namely insuredaterepartdf 
    	using toDF function
     */
    
    import spark.sqlContext.implicits._
    
    //val insuredaterepartdf = insuredatarepart.map(x=>(insureclass(x._1.toInt,x._2.toInt,x._3,x._4,x._5,x._6,x._7,x._8,x._9,x._10))).toDF
    
    val insuredaterepartdf = insuredatarepart.toDF
    insuredaterepartdf.show(5,false)
    
    
    /*
     * 21. Create structuretype for all the columns as per the insuranceinfo1.csv with the 
        columns such as IssuerId,IssuerId2,BusinessDate,StateCode,SourceName,NetworkName,
        NetworkURL,custnum,MarketCoverage,DentalOnlyPlan
        Hint: Do it carefully without making typo mistakes. Fields issuerid, issuerid2 should be of 
        IntegerType, businessDate should be DateType and all other fields are StringType, 
        ensure to import sql.types library.
     */
    
    
    import org.apache.spark.sql.types._
    import org.apache.spark.sql._
    import org.apache.spark.sql.functions._
      
    val dfstructtype = StructType(Array(StructField("IssuerId",IntegerType,true),
    StructField("IssuerId2",IntegerType,true),StructField("BusinessDate",DateType,true),StructField("StateCode",StringType,true)
    ,StructField("SourceName",StringType,true),StructField("NetworkName",StringType,true),StructField("NetworkURL",StringType,true)
    ,StructField("custnum",StringType,true),StructField("MarketCoverage",StringType,true),StructField("DentalOnlyPlan",StringType,true)))
    
     
    /*
     * 22. Create dataframes using the csv module with option to escape ‘,’ accessing the 
      insuranceinfo1.csv and insuranceinfo2.csv files and remove the footer from both 
      dataframes using header true, dropmalformed options and apply the schema of the 
      structure type created in the step 21.
     */
      
      var sqlctx=spark.sqlContext
      
      var usrcsvdf1 = sqlctx.read.option("header","true").option("inferschema","true").option("delimiter",",").option("mode","DROPMALFORMED").
      schema(dfstructtype).
      csv("hdfs://localhost:54310/user/hduser/sparkhack2/insuranceinfo1.csv","hdfs://localhost:54310/user/hduser/sparkhack2/insuranceinfo2.csv")
      
    var usrcsvdf = usrcsvdf1.select('IssuerId,'IssuerId2,date_format('BusinessDate,"dd-MM-yyyy").as("BusinessDate"),
          'StateCode,'SourceName,'NetworkName,'NetworkURL,'custnum,'MarketCoverage,'DentalOnlyPlan)

//        var usrcsvdf = usrcsvdf1.select(col("IssuerId"),col("IssuerId2"),to_date(col("BusinessDate"),"dd-MM-yyyy").as("BusinessDate"),
//                      col("StateCode"),col("SourceName"),col("NetworkName"),col("NetworkURL"),col("custnum"),col("MarketCoverage"),
//                      col("DentalOnlyPlan"))
    /*
     * 23. Apply the below DSL functions in the DFs created in step 22.
        a. Rename the fields StateCode and SourceName as stcd and srcnm respectively.
        b. Concat IssuerId,IssuerId2 as issueridcomposite and make it as a new field 
        Hint : Cast to string and concat.
        c. Remove DentalOnlyPlan column
        d. Add columns that should show the current system date and timestamp with the 
        fields name of sysdt and systs respectively.
     */
    
      /*
       * a. Rename the fields StateCode and SourceName as stcd and srcnm respectively.
       */
      val colrename = usrcsvdf.withColumnRenamed("StateCode","stcd").withColumnRenamed("SourceName","srcnm").show(3);      
           
      // import org.apache.spark.sql.functions.{col,lit,concat}
      
      /*
       * b. Concat IssuerId,IssuerId2 as issueridcomposite and make it as a new field 
				Hint : Cast to string and concat.
       */
      
      
       usrcsvdf.select(concat(col("IssuerId".toString()),col("IssuerId2".toString())).as("issueridcomposite")).show(5);
      
      
       usrcsvdf.withColumn("fullname",concat(col("StateCode"),col("SourceName"))).show(4)
     
      /*
       * c. Remove DentalOnlyPlan column 
       */
      val coldrop = usrcsvdf.drop("DentalOnlyPlan")
      
      coldrop.show(5)
      
      /*
       * d. Add columns that should show the current system date and timestamp with the 
       * fields name of sysdt and systs respectively.
       */
                  
      val sysdt_ts = usrcsvdf.withColumn("sysdt",current_date()).withColumn("systs",current_timestamp())
      
      sysdt_ts.select("sysdt","systs").show(5,false)

      
      /*
       * i. Identify all the column names and store in an array variable – use 
				    columns function
       */
      val dfcols = usrcsvdf.columns

      
      /*
       * ii. Identify all columns with datatype and store in an array variable – use dtypes function.
       */
      
      val dfdtyp = usrcsvdf.dtypes
      
      
      /*
       * iii. Identify all integer columns alone and store in an array variable.
       */
         
      val dfintcols = dfdtyp.filter(x=>x._2.contains ("IntegerType")).map(x=>x._1)
      
      
      /*
       * iv. Select only the integer columns identified in the above statement and show 10 records in the screen
       * 
       */
      
      
      val dfintcolrec = usrcsvdf.select(dfintcols.map(x=>col(x)):_*)
      
      dfintcolrec.show(10)
      
      /*
       * 24. Take the DF created in step 23.d and Remove the rows contains null in any one of the 
				field and count the number of rows which contains all columns with some value. 
       */
      
      // na functiona valid and ignore all the columns which holds NULL data
      
      val dfnotnullintcolsred = dfintcolrec.na.drop
      
      dfnotnullintcolsred.show(5)
      
      println("Not null data count from any of the column from the given DF:"+dfnotnullintcolsred.count)
      
      /*
       * 26. Import the package, instantiate the class and register the method generated in step 25 
				 as a udf 
				 for invoking in the DSL function.
       */
      val remspecialcharobj = new org.inceptez.hack.allmethods
       
      val udfrem = udf((remspecialcharobj).remspecialchar _)
      
      /*
       * 27. Call the above udf in the DSL by passing NetworkName column as an argument to get 
				 the special characters removed DF. 
       */
      // usrcsvdf.withColumn("Network_Name",udfrem('NetworkName)).select(col("Network_Name")).show(10,false);
      
      // val writedf1 = usrcsvdf.na.fill("NULL",Seq("NetworkName")).withColumn("Network_Name",udfrem('NetworkName))
      
            val writedf = usrcsvdf.na.fill("NULL",Seq("NetworkName")).select(col("IssuerId"), col("IssuerId2"),
                col("BusinessDate"),col("StateCode"),col("SourceName"),udfrem(col("NetworkName")) as ("NetworkName"),
                col("NetworkURL"),col("custnum"),col("MarketCoverage"),col("DentalOnlyPlan"))

      writedf. withColumn("Network_Name",udfrem('NetworkName))
      
      writedf.show(10,false);
      /*
       * 28. Save the DF generated in step 27 in JSON into HDFS with overwrite option.
       */ 
       
       writedf.write.mode("overwrite").json("hdfs://localhost:54310/user/hduser/sparkhack2/insure.json")
           
//       writedf.select (col("IssuerId"),col("IssuerId2"),col("BusinessDate"),col("StateCode"),col("SourceName"),
//           //udfrem(col("NetworkName")).as("NetworkName"),
//           col("NetworkURL"),col("custnum"),col("MarketCoverage"),
//           col("DentalOnlyPlan")).write.mode("overwrite").
//           json("hdfs://localhost:54310/user/hduser/sparkhack2/insure.json")
//           
       println("Json file write done...")
       
       writedf.write.mode("overwrite").option("delimiter","~").csv("hdfs://localhost:54310/user/hduser/sparkhack2/insure.csv")
       
       /*
        * 29. Save the DF generated in step 27 into CSV format with header name as per the DF and 
					delimited by ~ into HDFS with overwrite option.
        */
//       writedf.select (col("IssuerId"),col("IssuerId2"),col("BusinessDate"),col("StateCode"),col("SourceName"),
//           //udfrem(col("NetworkName")).as("NetworkName"),
//           col("NetworkURL"),col("custnum"),col("MarketCoverage"),
//           col("DentalOnlyPlan")).write.mode("overwrite").option("delimiter","~").
//           csv("hdfs://localhost:54310/user/hduser/sparkhack2/insure.csv")
//           
       println("CSV write with ~ delimited write done...")
       
       // writedf.write.mode("overwrite").option("delimiter","~").csv("hdfs://localhost:54310/user/hduser/sparkhack2/insure.csv")
       
       /*
        * 30. Save the DF generated in step 27 into hive external table and append the data without 
        overwriting it.
        */
       
       spark.sql("create database if not exists hackathon")
       
       spark.sql("use hackathon")
       
     //  spark.sql("DROP TABLE IF EXISTS insure ") 
       
       spark.sql("""
         create external table if not exists insure (IssuerId INT,IssuerId2 INT,BusinessDate date,StateCode String,SourceName String,
NetworkName String,NetworkURL String,custnum String,MarketCoverage String,DentalOnlyPlan String)
location "hdfs://localhost:54310/user/hive/warehouse"
         """)
       
       //writedf.coalesce(1).write.mode("append").format("hive").saveAsTable("insure")
       
       writedf.coalesce(1).write.mode("overwrite").format("hive").saveAsTable("insure")
       
       println("RDD to hive table write with append mode done ...")
    
    //  
    //  31. Load the file3 (custs_states.csv) from the HDFS location, using textfile API in an RDD 
    //custstates, this file contains 2 type of data one with 5 columns contains customer 
    //master info and other data with statecode and description of 2 columns.
    
       val custstates = sc.textFile("hdfs://localhost:54310/user/hduser/sparkhack2/custs_states.csv")
    //
    //32. Split the above data into 2 RDDs, first RDD namely custfilter should be loaded only with 
    //5 columns data and second RDD namely statesfilter should be only loaded with 2 
    //columns data.      

           
    val custfilter =  custstates.map(x=>x.trim).map(_.split(",")).filter (l=>l.length >5 )
    
    val statesfilter =  custstates.map(x=>x.trim).map(_.split(",")).filter (l=>l.length ==2 )
    
    //33. Load the file3 (custs_states.csv) from the HDFS location, using CSV Module in a DF 
    //custstatesdf, this file contains 2 type of data one with 5 columns contains customer 
    //master info and other data with statecode and description of 2 columns.
    
    val custstatesdf = spark.read.csv("hdfs://localhost:54310/user/hduser/sparkhack2/custs_states.csv")
    
    //    34. Split the above data into 2 DFs, first DF namely custfilterdf should be loaded only with 5 
    //columns data and second DF namely statesfilterdf should be only loaded with 2 columns 
    //data.
    //Hint: Use filter/where DSL function to check isnull or isnotnull to achieve the above 
    //functionality then rename, change the type and drop columns in the above 2 DFs 
    //accordingly
      
    val custfilterdf=custstatesdf.filter ("_c2 is not null and _c3 is not null").
    select ('_c0 as "custID",'_c1 as "fname",'_c2 as "lname",'_c3 as "age",'_c4 as "profession")
    
    custfilterdf.show(10)
    
    
    val statesfilterdf = custstatesdf.filter ("_c2 is null and _c1 is not null").select ($"_c0" as "cityCode",$"_c1" as "cityName")
    
    statesfilterdf.show(10)
    
    //35. Register the above step 34 DFs as temporary views as custview and statesview.
    
    custfilterdf.createOrReplaceTempView("custview")
    
    
    statesfilterdf.createOrReplaceTempView("statesview")
  
    
    //36. Register the DF generated in step 23.d as a tempview namely insureview
    
    coldrop.createOrReplaceTempView("insureview")
    spark.sql ("select * from insureview").show(10,false)
    

    //37. Import the package, instantiate the class and Register the method created in step 25 in the name of remspecialcharudf 
    // using spark udf registration.
  
    spark.udf.register("remspecialcharudf", dtck1.remspecialchar _)
    
    //38. Write an SQL query with the below processing – set the spark.sql.shuffle.partitions to 4
    //a. Pass NetworkName to remspecialcharudf and get the new column called cleannetworkname
    //b. Add current date, current timestamp fields as curdt and curts.
    //c. Extract the year and month from the businessdate field and get it as 2 new fields called yr,mth respectively.
    //d. Extract from the protocol either http/https from the NetworkURL column, if http 
    //then print http non secured if https then secured else no protocol found then 
    //display noprotocol. For Eg: if http://www2.dentemax.com/ then show http non 
    //secured else if https://www2.dentemax.com/ then http secured else if
    //www.bridgespanhealth.com then show as no protocol store in a column called 
    //protocol. 
    //e. Display all the columns from insureview including the columns derived from 
    //above a, b, c, d steps with statedesc column from statesview with age,profession 
    //column from custview . Do an Inner Join of insureview with statesview using 
    //stcd=stated and join insureview with custview using custnum=custid.
  
     
    
    //a. Pass NetworkName to remspecialcharudf and get the new column called cleannetworkname
    spark.conf.set("spark.sql.shuffle.partitions",4)
    spark.sql("select remspecialcharudf(NetworkName) as cleannetworkname from insureview").show(10,false)

    
     //b. Add current date, current timestamp fields as curdt and curts.
     spark.sql("select current_date as curdt,current_timestamp as curts from insureview").show(10,false)
   
     //c. Extract the year and month from the businessdate field and get it as 2 new fields called yr,mth respectively.
     spark.sql("select distinct  extract (year from BusinessDate) as yr from insureview").show(5)
     spark.sql("select distinct  extract (month from BusinessDate) as mth from insureview").show(5)
    
     //d. Extract from the protocol either http/https from the NetworkURL column, if http 
     
      //e. Display all the columns from insureview including the columns derived from 
      //above a, b, c, d steps with statedesc column from statesview with age,profession 
      //column from custview . Do an Inner Join of insureview with statesview using 
      //stcd=stated and join insureview with custview using custnum=custid.
      
      
     
     spark.sql("""select remspecialcharudf(NetworkName) as cleannetworkname,current_date as curdt,current_timestamp as curts,  
     extract (year from BusinessDate) as yr, extract (month from BusinessDate) as mth,age,profession,cityName from insureview,statesview,
     custview where insureview.StateCode=statesview.cityCode and insureview.custnum=custview.custid""").show(10)
     
     
     
     val parqfile = spark.sql("""select remspecialcharudf(NetworkName) as cleannetworkname,current_date as curdt,current_timestamp as curts, 
        extract (year from BusinessDate) as yr, extract (month from BusinessDate) as mth,age,profession,cityName from insureview,statesview,
        custview where insureview.StateCode=statesview.cityCode and insureview.custnum=custview.custid""")
     
     //39. Store the above selected Dataframe in Parquet formats in a HDFS location as a single file.
     
       parqfile.coalesce(1).write.mode("overwrite").parquet("hdfs://localhost:54310/user/hduser/sparkhack2/parqfile.parquet")
     
       println("parquet file write done...")  
  }
      
}